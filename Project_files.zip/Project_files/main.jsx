import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f4c05f2b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=f4c05f2b"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=f4c05f2b"; const ReactDOM = __vite__cjsImport2_reactDom_client.__esModule ? __vite__cjsImport2_reactDom_client.default : __vite__cjsImport2_reactDom_client;
import "/src/index.css";
import App from "/src/App.jsx?t=1736956071425";
import ContextProvider from "/src/context/Context.jsx";
ReactDOM.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxDEV(ContextProvider, { children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
    fileName: "D:/ReactJs/Gemini-AI/gemini-clone/src/main.jsx",
    lineNumber: 9,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "D:/ReactJs/Gemini-AI/gemini-clone/src/main.jsx",
    lineNumber: 8,
    columnNumber: 3
  }, this)
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUUk7QUFSSixPQUFPQSxXQUFXO0FBQ2xCLE9BQU9DLGNBQWM7QUFDckIsT0FBTztBQUNQLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MscUJBQXFCO0FBRTVCRixTQUFTRyxXQUFXQyxTQUFTQyxlQUFlLE1BQU0sQ0FBQyxFQUFFQztBQUFBQSxFQUNuRCx1QkFBQyxtQkFDQyxpQ0FBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBSSxLQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUNGIiwibmFtZXMiOlsiUmVhY3QiLCJSZWFjdERPTSIsIkFwcCIsIkNvbnRleHRQcm92aWRlciIsImNyZWF0ZVJvb3QiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwicmVuZGVyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIm1haW4uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCBSZWFjdERPTSBmcm9tICdyZWFjdC1kb20vY2xpZW50J1xuaW1wb3J0ICcuL2luZGV4LmNzcydcbmltcG9ydCBBcHAgZnJvbSAnLi9BcHAuanN4J1xuaW1wb3J0IENvbnRleHRQcm92aWRlciBmcm9tICcuL2NvbnRleHQvQ29udGV4dC5qc3gnXG5cblJlYWN0RE9NLmNyZWF0ZVJvb3QoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jvb3QnKSkucmVuZGVyKFxuICA8Q29udGV4dFByb3ZpZGVyPlxuICAgIDxBcHAgLz5cbiAgPC9Db250ZXh0UHJvdmlkZXI+LFxuKVxuIl0sImZpbGUiOiJEOi9SZWFjdEpzL0dlbWluaS1BSS9nZW1pbmktY2xvbmUvc3JjL21haW4uanN4In0=